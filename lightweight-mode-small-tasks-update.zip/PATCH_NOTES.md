# Patch Notes: Lightweight Mode for Small Tasks

This patch implements the 6th recommended improvement: **Add lightweight mode for small tasks**.

## Intent

The full AI workflow is valuable for medium/large or architecture-sensitive work, but can be too heavy for small local tasks. This patch adds a controlled fast lane:

```text
Issue / request / brainstorm summary
-> Lightweight Plan
-> Implementation
-> Lightweight Review
```

The fast lane is allowed only when the task is small, local, low-risk, and does not require PRD, Architecture, ADR, or Roadmap work.

## Included Files

```text
docs/workflow/
├── ARTIFACT_DECISION_MATRIX.md
├── HANDOFF_CONTRACTS.md
├── LIGHTWEIGHT_TASK_MODE.md
└── NEXT_STEP_TYPES.md

brainstorm-gate/
├── SKILL.md
├── assets/LIGHTWEIGHT_BRAINSTORM_RESPONSE_TEMPLATE.md
├── references/LIGHTWEIGHT_TASK_MODE.md
└── scripts/check_lightweight_brainstorm.py

plan-writer/
├── SKILL.md
├── assets/LIGHTWEIGHT_PLAN_TEMPLATE.md
├── references/LIGHTWEIGHT_PLAN_GUIDE.md
└── scripts/check_lightweight_plan.py

implement-task/
├── SKILL.md
├── assets/LIGHTWEIGHT_IMPLEMENTATION_SUMMARY_TEMPLATE.md
├── references/LIGHTWEIGHT_IMPLEMENTATION_GUIDE.md
└── scripts/check_lightweight_implementation_report.py

review-phase/
├── SKILL.md
├── assets/LIGHTWEIGHT_TASK_REVIEW_REPORT_TEMPLATE.md
├── references/LIGHTWEIGHT_REVIEW_GUIDE.md
└── scripts/check_lightweight_review_report.py

scripts/check_lightweight_mode.py
```

## Behavioral Changes

### Brainstorm Gate

Adds `USE_LIGHTWEIGHT_MODE` as a valid routing decision when the request is small/local/low-risk.

### Plan Writer

Adds `LIGHTWEIGHT_PLAN` mode with a compact required template.

### Implement Task

Adds `LIGHTWEIGHT_PLAN_IMPLEMENTATION` behavior and escalation triggers.

### Review Phase

Adds `LIGHTWEIGHT_TASK_REVIEW` mode.

### Shared Docs

Adds `LIGHTWEIGHT_TASK_MODE.md` and wires lightweight mode into the decision matrix, handoff contracts, and next-step type rules.

## Guardrails

Lightweight mode must not be used when the task introduces or changes:

- product behavior ambiguity
- architecture boundaries
- data ownership/source-of-truth
- integration or async flow
- transaction/consistency/idempotency/retry behavior
- authorization/security
- observability/deployment/runtime behavior
- performance/scalability assumptions
- ADR-worthy decisions
- roadmap sequencing

## Apply

From the extracted zip:

```bash
cp -r docs brainstorm-gate plan-writer implement-task review-phase scripts <target-repo>/
```

## Recommended Next Step

After applying, run a lightweight validation on a sample output:

```bash
python scripts/check_lightweight_mode.py <sample-lightweight-output.md>
```
